/* =========================================================
   CYBERSHIELD AI
   Main JavaScript
   ========================================================= */


/* =========================================================
   GLOBAL VARIABLES
   ========================================================= */

let detectionChart;
let analyticsChart;


/* =========================================================
   PAGE NAVIGATION
   ========================================================= */

const navItems = document.querySelectorAll(".nav-item");

const sections = document.querySelectorAll(".page-section");

const pageTitle = document.getElementById("pageTitle");


navItems.forEach(item => {

    item.addEventListener("click", () => {

        const sectionId = item.dataset.section;

        showSection(sectionId);

    });

});


function showSection(sectionId) {

    sections.forEach(section => {

        section.classList.remove("active-section");

    });


    const selectedSection =
        document.getElementById(sectionId);

    if (selectedSection) {

        selectedSection.classList.add("active-section");

    }


    navItems.forEach(item => {

        item.classList.remove("active");

        if (item.dataset.section === sectionId) {

            item.classList.add("active");

        }

    });


    const titles = {

        dashboard: "Dashboard",

        scanner: "URL Scanner",

        threats: "Threat Intelligence",

        analytics: "Analytics",

        methodology: "Methodology",

        about: "About Project"

    };


    pageTitle.textContent =
        titles[sectionId] || "Dashboard";


    window.scrollTo({

        top: 0,

        behavior: "smooth"

    });


    if (sectionId === "analytics") {

        setTimeout(() => {

            createAnalyticsChart();

        }, 100);

    }

}


/* =========================================================
   MOBILE SIDEBAR
   ========================================================= */

const mobileMenu =
    document.getElementById("mobileMenu");

const sidebar =
    document.querySelector(".sidebar");


if (mobileMenu) {

    mobileMenu.addEventListener("click", () => {

        sidebar.classList.toggle("open");

    });

}


/* =========================================================
   STAT COUNTER ANIMATION
   ========================================================= */

function animateCounters() {

    const counters =
        document.querySelectorAll(".stat-value[data-target]");


    counters.forEach(counter => {

        const target =
            Number(counter.dataset.target);

        let current = 0;

        const increment =
            target / 60;


        const updateCounter = () => {

            current += increment;


            if (current < target) {

                counter.textContent =
                    Math.floor(current).toLocaleString();

                requestAnimationFrame(updateCounter);

            } else {

                counter.textContent =
                    target.toLocaleString();

            }

        };


        updateCounter();

    });

}


/* =========================================================
   CHART.JS
   ========================================================= */

function createDetectionChart() {

    const canvas =
        document.getElementById("detectionChart");

    if (!canvas) return;


    if (detectionChart) {

        detectionChart.destroy();

    }


    const context =
        canvas.getContext("2d");


    detectionChart =
        new Chart(context, {

            type: "line",

            data: {

                labels: [
                    "Mon",
                    "Tue",
                    "Wed",
                    "Thu",
                    "Fri",
                    "Sat",
                    "Sun"
                ],

                datasets: [

                    {

                        label: "Legitimate",

                        data: [
                            820,
                            940,
                            890,
                            1080,
                            1150,
                            1020,
                            1190
                        ],

                        borderColor: "#16a34a",

                        backgroundColor:
                            "rgba(22,163,74,0.08)",

                        borderWidth: 2,

                        tension: 0.4,

                        fill: true,

                        pointRadius: 3,

                        pointBackgroundColor: "#16a34a"

                    },

                    {

                        label: "Phishing",

                        data: [
                            150,
                            210,
                            185,
                            250,
                            230,
                            280,
                            245
                        ],

                        borderColor: "#dc2626",

                        backgroundColor:
                            "rgba(220,38,38,0.06)",

                        borderWidth: 2,

                        tension: 0.4,

                        fill: true,

                        pointRadius: 3,

                        pointBackgroundColor: "#dc2626"

                    }

                ]

            },

            options: {

                responsive: true,

                maintainAspectRatio: false,

                plugins: {

                    legend: {

                        position: "top",

                        align: "end",

                        labels: {

                            boxWidth: 8,

                            boxHeight: 8,

                            font: {

                                size: 9,

                                family: "Inter"

                            }

                        }

                    }

                },

                scales: {

                    x: {

                        grid: {

                            display: false

                        },

                        ticks: {

                            font: {

                                size: 8

                            },

                            color: "#98a2b3"

                        }

                    },

                    y: {

                        beginAtZero: true,

                        grid: {

                            color: "#f0f2f5"

                        },

                        ticks: {

                            font: {

                                size: 8

                            },

                            color: "#98a2b3"

                        }

                    }

                }

            }

        });

}


/* =========================================================
   ANALYTICS CHART
   ========================================================= */

function createAnalyticsChart() {

    const canvas =
        document.getElementById("analyticsChart");

    if (!canvas) return;


    if (analyticsChart) {

        analyticsChart.destroy();

    }


    const context =
        canvas.getContext("2d");


    analyticsChart =
        new Chart(context, {

            type: "bar",

            data: {

                labels: [
                    "Monday",
                    "Tuesday",
                    "Wednesday",
                    "Thursday",
                    "Friday",
                    "Saturday",
                    "Sunday"
                ],

                datasets: [

                    {

                        label: "Safe URLs",

                        data: [
                            820,
                            940,
                            890,
                            1080,
                            1150,
                            1020,
                            1190
                        ],

                        backgroundColor: "#2563eb",

                        borderRadius: 5

                    },

                    {

                        label: "Phishing URLs",

                        data: [
                            150,
                            210,
                            185,
                            250,
                            230,
                            280,
                            245
                        ],

                        backgroundColor: "#dc2626",

                        borderRadius: 5

                    }

                ]

            },

            options: {

                responsive: true,

                maintainAspectRatio: false,

                plugins: {

                    legend: {

                        position: "top",

                        labels: {

                            boxWidth: 10,

                            font: {

                                size: 9,

                                family: "Inter"

                            }

                        }

                    }

                },

                scales: {

                    x: {

                        grid: {

                            display: false

                        },

                        ticks: {

                            font: {

                                size: 8

                            }

                        }

                    },

                    y: {

                        beginAtZero: true,

                        grid: {

                            color: "#f0f2f5"

                        },

                        ticks: {

                            font: {

                                size: 8

                            }

                        }

                    }

                }

            }

        });

}


/* =========================================================
   URL VALIDATION
   ========================================================= */

function isValidURL(value) {

    try {

        const url =
            new URL(value);

        return (
            url.protocol === "http:" ||
            url.protocol === "https:"
        );

    } catch {

        return false;

    }

}


/* =========================================================
   SIMPLE DEMO RISK ANALYSIS
   ========================================================= */

/*
    IMPORTANT:

    This function is only a FRONTEND DEMO.

    Your actual Random Forest model will later
    be connected through a Python backend/API.

    The current function creates a demo result
    so that the website works before backend
    integration.
*/

function analyzeURL(url) {

    const suspiciousWords = [

        "login",
        "verify",
        "account",
        "secure",
        "update",
        "bank",
        "password",
        "confirm",
        "free",
        "gift",
        "claim",
        "signin"

    ];


    const lowerURL =
        url.toLowerCase();


    let riskScore = 10;


    /* URL length */

    if (url.length > 60) {

        riskScore += 15;

    }

    if (url.length > 100) {

        riskScore += 15;

    }


    /* Suspicious words */

    suspiciousWords.forEach(word => {

        if (lowerURL.includes(word)) {

            riskScore += 8;

        }

    });


    /* IP address */

    const ipPattern =
        /https?:\/\/(\d{1,3}\.){3}\d{1,3}/;

    if (ipPattern.test(url)) {

        riskScore += 25;

    }


    /* @ symbol */

    if (url.includes("@")) {

        riskScore += 20;

    }


    /* Too many hyphens */

    const hyphens =
        (url.match(/-/g) || []).length;

    if (hyphens > 3) {

        riskScore += 10;

    }


    /* Too many subdomains */

    try {

        const parsedURL =
            new URL(url);

        const parts =
            parsedURL.hostname.split(".");

        if (parts.length > 4) {

            riskScore += 15;

        }

    } catch {

        riskScore += 20;

    }


    riskScore =
        Math.min(riskScore, 98);


    const phishing =
        riskScore >= 50;


    const confidence =
        phishing
            ? Math.max(75, riskScore + 35)
            : Math.max(90, 100 - riskScore);


    return {

        phishing,

        riskScore,

        confidence: Math.min(confidence, 99)

    };

}


/* =========================================================
   SCANNER - DASHBOARD
   ========================================================= */

const scanForm =
    document.getElementById("scanForm");

const urlInput =
    document.getElementById("urlInput");

const clearBtn =
    document.getElementById("clearBtn");


if (urlInput) {

    urlInput.addEventListener("input", () => {

        clearBtn.style.display =
            urlInput.value.length > 0
                ? "block"
                : "none";

    });

}


if (clearBtn) {

    clearBtn.addEventListener("click", () => {

        urlInput.value = "";

        clearBtn.style.display = "none";

        urlInput.focus();

    });

}


if (scanForm) {

    scanForm.addEventListener("submit", event => {

        event.preventDefault();


        const value =
            urlInput.value.trim();


        if (!value) {

            showToast(
                "Enter URL",
                "Please enter a website URL to scan.",
                "error"
            );

            urlInput.focus();

            return;

        }


        let formattedURL = value;


        if (
            !formattedURL.startsWith("http://") &&
            !formattedURL.startsWith("https://")
        ) {

            formattedURL =
                "https://" + formattedURL;

        }


        if (!isValidURL(formattedURL)) {

            showToast(
                "Invalid URL",
                "Please enter a valid website address.",
                "error"
            );

            return;

        }


        showSection("scanner");


        const mainInput =
            document.getElementById("mainUrlInput");


        mainInput.value =
            formattedURL;


        setTimeout(() => {

            performScan(formattedURL);

        }, 250);

    });

}


/* =========================================================
   MAIN SCANNER
   ========================================================= */

const mainScanForm =
    document.getElementById("mainScanForm");


if (mainScanForm) {

    mainScanForm.addEventListener("submit", event => {

        event.preventDefault();


        const input =
            document.getElementById("mainUrlInput");


        let value =
            input.value.trim();


        if (!value) {

            showToast(
                "Enter URL",
                "Please enter a website URL first.",
                "error"
            );

            input.focus();

            return;

        }


        if (
            !value.startsWith("http://") &&
            !value.startsWith("https://")
        ) {

            value =
                "https://" + value;

        }


        if (!isValidURL(value)) {

            showToast(
                "Invalid URL",
                "Please enter a valid website address.",
                "error"
            );

            return;

        }


        performScan(value);

    });

}


/* =========================================================
   PERFORM SCAN
   ========================================================= */

function performScan(url) {

    const result =
        document.getElementById("scanResult");


    result.classList.remove("hidden");


    /* Loading state */

    result.innerHTML = `

        <div style="
            text-align:center;
            padding:35px;
        ">

            <div style="
                width:38px;
                height:38px;
                border:3px solid #e5e7eb;
                border-top-color:#2563eb;
                border-radius:50%;
                margin:0 auto 15px;
                animation:spin 0.8s linear infinite;
            "></div>

            <strong style="
                font-size:12px;
            ">
                Analyzing URL...
            </strong>

            <p style="
                color:#98a2b3;
                font-size:9px;
                margin-top:5px;
            ">
                Checking URL security characteristics
            </p>

        </div>

    `;


    setTimeout(() => {

        const analysis =
            analyzeURL(url);


        displayResult(
            url,
            analysis
        );


        addRecentScan(
            url,
            analysis
        );


        showToast(
            "Scan Complete",
            "URL analysis has been completed.",
            analysis.phishing
                ? "error"
                : "success"
        );


    }, 1000);

}


/* =========================================================
   DISPLAY RESULT
   ========================================================= */

function displayResult(url, analysis) {

    const result =
        document.getElementById("scanResult");


    const phishing =
        analysis.phishing;


    const title =
        phishing
            ? "Potential Phishing Detected"
            : "Website Appears Safe";


    const prediction =
        phishing
            ? "Phishing"
            : "Legitimate";


    const risk =
        phishing
            ? "High"
            : "Low";


    const icon =
        phishing
            ? "!"
            : "✓";


    const iconBackground =
        phishing
            ? "#fef2f2"
            : "#f0fdf4";


    const iconColor =
        phishing
            ? "#dc2626"
            : "#16a34a";


    const ringColor =
        phishing
            ? "#dc2626"
            : "#16a34a";


    result.innerHTML = `

        <div class="result-header">

            <div
                class="result-status-icon"
                style="
                    background:${iconBackground};
                    color:${iconColor};
                "
            >
                ${icon}
            </div>

            <div>

                <span class="eyebrow">
                    ANALYSIS COMPLETE
                </span>

                <h2>
                    ${title}
                </h2>

            </div>

        </div>


        <div class="result-url">

            ${escapeHTML(url)}

        </div>


        <div class="result-score">

            <div
                class="score-ring"
                style="
                    background:
                    conic-gradient(
                        ${ringColor}
                        0 ${analysis.confidence}%,
                        #e5e7eb
                        ${analysis.confidence}% 100%
                    );
                "
            >

                <div>

                    <strong>
                        ${analysis.confidence}%
                    </strong>

                    <span>
                        Confidence
                    </span>

                </div>

            </div>


            <div class="result-details">

                <div class="detail-row">

                    <span>
                        Prediction
                    </span>

                    <strong style="
                        color:${iconColor};
                    ">
                        ${prediction}
                    </strong>

                </div>


                <div class="detail-row">

                    <span>
                        Risk Level
                    </span>

                    <strong>
                        ${risk}
                    </strong>

                </div>


                <div class="detail-row">

                    <span>
                        Risk Score
                    </span>

                    <strong>
                        ${analysis.riskScore}/100
                    </strong>

                </div>


                <div class="detail-row">

                    <span>
                        Model
                    </span>

                    <strong>
                        Random Forest
                    </strong>

                </div>

            </div>

        </div>


        <div class="indicators">

            <h3>
                Security Indicators
            </h3>


            <div class="indicator-grid">

                <div class="indicator">

                    <span
                        style="
                            color:${iconColor};
                            background:${iconBackground};
                        "
                    >
                        ${phishing ? "!" : "✓"}
                    </span>

                    <div>

                        <strong>
                            URL Structure
                        </strong>

                        <small>
                            ${phishing
                                ? "Needs review"
                                : "Normal"}
                        </small>

                    </div>

                </div>


                <div class="indicator">

                    <span
                        style="
                            color:${iconColor};
                            background:${iconBackground};
                        "
                    >
                        ${phishing ? "!" : "✓"}
                    </span>

                    <div>

                        <strong>
                            Domain Pattern
                        </strong>

                        <small>
                            ${phishing
                                ? "Suspicious"
                                : "Low Risk"}
                        </small>

                    </div>

                </div>


                <div class="indicator">

                    <span
                        style="
                            color:${iconColor};
                            background:${iconBackground};
                        "
                    >
                        ${phishing ? "!" : "✓"}
                    </span>

                    <div>

                        <strong>
                            Suspicious Characters
                        </strong>

                        <small>
                            ${phishing
                                ? "Detected"
                                : "Not Detected"}
                        </small>

                    </div>

                </div>


                <div class="indicator">

                    <span
                        style="
                            color:${iconColor};
                            background:${iconBackground};
                        "
                    >
                        ${phishing ? "!" : "✓"}
                    </span>

                    <div>

                        <strong>
                            Threat Pattern
                        </strong>

                        <small>
                            ${phishing
                                ? "Potential threat"
                                : "Not Detected"}
                        </small>

                    </div>

                </div>

            </div>

        </div>

    `;

}


/* =========================================================
   ADD RECENT SCAN
   ========================================================= */

function addRecentScan(url, analysis) {

    const table =
        document.getElementById("recentScans");


    if (!table) return;


    const row =
        document.createElement("tr");


    const phishing =
        analysis.phishing;


    const domain =
        getDomain(url);


    row.innerHTML = `

        <td>

            <div class="url-cell">

                <span class="site-icon">
                    ${domain.charAt(0).toUpperCase()}
                </span>

                ${escapeHTML(domain)}

            </div>

        </td>


        <td>

            <span class="
                badge
                ${phishing ? "danger" : "safe"}
            ">

                ${phishing
                    ? "High Risk"
                    : "Low Risk"}

            </span>

        </td>


        <td>

            <span class="
                prediction
                ${phishing
                    ? "danger-text"
                    : "safe-text"}
            ">

                ${phishing
                    ? "⚠ Phishing"
                    : "✓ Legitimate"}

            </span>

        </td>


        <td>
            ${analysis.confidence}%
        </td>


        <td>
            Just now
        </td>

    `;


    table.insertBefore(
        row,
        table.firstChild
    );


    /* Keep only latest 5 */

    while (table.children.length > 5) {

        table.removeChild(
            table.lastChild
        );

    }

}


/* =========================================================
   GET DOMAIN
   ========================================================= */

function getDomain(url) {

    try {

        return new URL(url).hostname;

    } catch {

        return url;

    }

}


/* =========================================================
   ESCAPE HTML
   ========================================================= */

function escapeHTML(value) {

    return value
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");

}


/* =========================================================
   TOAST
   ========================================================= */

const toast =
    document.getElementById("toast");

const toastTitle =
    document.getElementById("toastTitle");

const toastMessage =
    document.getElementById("toastMessage");

const closeToast =
    document.getElementById("closeToast");


let toastTimer;


function showToast(
    title,
    message,
    type = "success"
) {

    toastTitle.textContent =
        title;

    toastMessage.textContent =
        message;


    const icon =
        toast.querySelector(".toast-icon");


    if (type === "error") {

        icon.textContent = "!";

        icon.style.background =
            "#fef2f2";

        icon.style.color =
            "#dc2626";

    } else {

        icon.textContent = "✓";

        icon.style.background =
            "#f0fdf4";

        icon.style.color =
            "#16a34a";

    }


    toast.classList.add("show");


    clearTimeout(toastTimer);


    toastTimer =
        setTimeout(() => {

            toast.classList.remove("show");

        }, 3500);

}


if (closeToast) {

    closeToast.addEventListener(
        "click",
        () => {

            toast.classList.remove("show");

        }
    );

}


/* =========================================================
   NOTIFICATION
   ========================================================= */

const notificationBtn =
    document.getElementById("notificationBtn");


if (notificationBtn) {

    notificationBtn.addEventListener(
        "click",
        () => {

            showToast(
                "Security Alerts",
                "3 security notifications are available."
            );

        }
    );

}


/* =========================================================
   CHART PERIOD
   ========================================================= */

const chartPeriod =
    document.getElementById("chartPeriod");


if (chartPeriod) {

    chartPeriod.addEventListener(
        "change",
        event => {

            showToast(
                "Chart Updated",
                `Showing data for ${event.target.value}.`
            );

        }
    );

}


/* =========================================================
   INITIALIZE
   ========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        animateCounters();

        createDetectionChart();

    }
);


/* =========================================================
   ADD CSS ANIMATION DYNAMICALLY
   ========================================================= */

const style =
    document.createElement("style");


style.textContent = `

@keyframes spin {

    from {
        transform: rotate(0deg);
    }

    to {
        transform: rotate(360deg);
    }

}

`;


document.head.appendChild(style);